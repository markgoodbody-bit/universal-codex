# NIST AI RMF 1.0 Mapping — Universal Codex v1.1.1

- GOVERN: SCAR, signatures, replication.
- MAP: Spine order, contracts.
- MEASURE: Eval logs, drift metrics, bootstrap π.
- MANAGE: SCAR closure, adversarial replication, override caps.

# EU AI Act Mapping (Arts 9–13, 52, 61) — Universal Codex v1.1.1

- Art. 9 Risk mgmt: Invariants + gates + SCAR.
- Art. 10 Data governance: Consent + VC revocation.
- Art. 11 Technical docs: contracts/ + spine.
- Art. 12 Records: Eval logs per contract.
- Art. 13 Transparency: Rationale + hashes.
- Art. 52 Transparency: Lay summaries.
- Art. 61 Post-market: Telemetry + SCAR SLA.

# GLYPH_LEXICON v1.0.10 (ASCII-canonical)
[FALSIFY_FIRST] = run disconfirmation before permit.
[DRIFT] = distribution shift detected.
[SPINE_PIN] = order + interfaces are fixed.
All glyphs must map to ASCII tags in outputs; glyphs are optional.

# GLYPH LEXICON — 1.0.6-RFC2 (ASCII is canonical)

- [FALSIFY_FIRST]  :: optional glyph ⟁
- [MED_CONFIDENCE] :: ⊙
- [PATCHABLE]      :: ◐

Always publish ASCII tags; glyphs are purely cosmetic.

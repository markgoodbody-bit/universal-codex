﻿# Kernel Aggregation

(TBD: Claude to fill  explicit Σ harms, ΔΦ_K definition, two worked examples)

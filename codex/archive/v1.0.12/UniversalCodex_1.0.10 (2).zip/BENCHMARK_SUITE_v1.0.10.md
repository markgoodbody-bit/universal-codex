# BENCHMARK_SUITE v1.0.10
Tracks (examples):
- Clinical triage: FP≤5%%, FN≤10%%; α≥0.99; EDD 7–14d; FAR≤2%%/wk.
- Justice pre-trial: publish liberty-vs-safety weights; κ≥0.7 rubric agreement.
- Propaganda stressor: diversity triad (entropy, embedding distance, min-hash); abstain on low diversity.

Reporting (weekly): p05/p50/p95 & max for EDD, FAR, TTD; abstain_cost proxy disclosed.

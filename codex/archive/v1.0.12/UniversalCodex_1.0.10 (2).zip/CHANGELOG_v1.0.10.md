# CHANGELOG v1.0.10
- Consolidated RFC fixes into a single universal payload.
- Clarified hashing protocol; JSON interfaces documented.
- Added dynamic AGREE_SKIPPED cap; tightened governance π to 15%%.
- Benchmarks include diversity triad for propaganda track.
- All glyphs mapped to ASCII; ASCII is canonical.

# CHANGELOG v1.0.9-RFC5

- RFC5: event-driven pentests on any config change; CDI histograms; config-entropy (KL) metric; cross-domain MAUT bounds (+-10%); SCAR closure SLA (>=1 closed per domain per quarter with replication); unstructured AGREE adapter with normalization; appeal funding SLA; NON_INSTRUMENT renewal cap; pi_90d tightened to <=15%; synchronized escalation ladder; fallback quorum; hashing backups with SLA; triage sampling strata and comprehension feedback loop.

# Lattice overview

- **Ξ**: goal, error reduction, time-to-correction, witness agreement
- **Φ_K**: care, clarity, consent, agency
- **Guards**: P7–P17
- **Kill conditions**: K1–K5

See `docs/3_falsification.md` for how to test/kill the system.

# Benchmark Suite v1.0.15
Smoke A–D; domain tracks (clinical, justice, propaganda, AV).

Baselines: prior, un‑kernelled, peer median; else synthetic adversarial baseline.
Success: CVaR ≤ baseline−10%; FN ≤ baseline+2% abs; FAR ≤2%/wk; π(90d) ≤15%; audits ≥95% weeks.
Publish weekly p05/p50/p95/max for EDD/FAR/TTD + CDI/KL histograms + ABSTAIN_COST z‑scores.

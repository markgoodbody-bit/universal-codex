﻿# Overlay Merge Policy

(TBD: Claude to fill  object-only weights, merge order = header.overlays (leftright, last wins),
renormalize to 1.0 (fail in --strict if |factor-1| > 10%), examples with KND-K + K_TECH + K_COLLAB)
